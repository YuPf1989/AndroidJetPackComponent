package com.rain.androidjetpackcomponent.workmanager;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;

import com.rain.androidjetpackcomponent.R;

/**
 * Author:rain
 * Date:2018/11/2 16:19
 * Description:
 * WorkManager使用:
 * WorkManager适用于那些即使应用程序退出，系统也能够保证这个任务正常运行的场景，
 * 比如将应用程序数据上传到服务器。它不适用于应用进程内的后台工作，如果应用进程消失，就可以安全地终止，对于这种情况，推荐你使用线程池
 */
public class WorkmanagerActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workmanager);
    }
}
